from pyspark.sql import Row
import boto3
from datetime import datetime
from pyspark.sql import SparkSession, Row
import fnmatch
import uuid
#***********************************************************************************************
# Get the list of staged files
#   1) If the source extract type is incremental, get the list of staged (unprocessed) files
#      in ascending order of date received, so the first file arrived is the first in list
#   2) If the source extract type is full, get the list of files in the descending order of
#      date received, so the last file arrived is first in the list
#***********************************************************************************************
def collect_all_files(p_src_sys_rec, p_src_entity_rec)->list:
    #
    l_botoclient = boto3.client('s3')
    #    
    l_path_tokens = p_src_sys_rec["src_entity_path"].split("/")
    l_bucket_name = l_path_tokens[2]
    l_path_prefix = "/".join(l_path_tokens[3:])
    #
    l_entity_search_pattern = p_src_entity_rec["src_entity_pattern"]
    #
    if (l_entity_search_pattern.startswith("*")):
            l_src_entity_prefix = l_path_prefix + "/"
    elif ("*" in l_entity_search_pattern ):
            l_src_entity_prefix = l_path_prefix + "/" + l_entity_search_pattern[0:l_entity_search_pattern.index("*")]
    else:
            l_src_entity_prefix = l_path_prefix + "/" + l_entity_search_pattern
    #    
    l_file_filter  = l_path_prefix + "/" + l_entity_search_pattern
    print(f"Searching in s3 bucket={l_bucket_name}, prefix={l_src_entity_prefix} for files {p_src_entity_rec['src_entity_pattern']}","both")
    # Create a paginator
    
    l_paginator = l_botoclient.get_paginator('list_objects_v2')
    # Paginate through the objects
    l_page_iterator = l_paginator.paginate(Bucket=l_bucket_name,Prefix=l_src_entity_prefix)
   
    for page in l_page_iterator:        
        if 'Contents' in page:
            l_entity_recs = [
                Row(
                     src_entity_inst_key = "{ftime}.{fsys}.{fname}".format(  
                                                    ftime = entity_s3_rec['LastModified'].strftime("%Y%m%d.%H%M%S.%f"),
                                                    fsys = p_src_sys_rec["src_sys_key"], 
                                                    fname = p_src_entity_rec["src_entity_key"]) ,                                   
                    src_sys_key = p_src_entity_rec["src_sys_key"],
                    src_entity_last_inst_no = p_src_entity_rec["src_entity_last_inst_no"] ,
                    src_entity_key = p_src_entity_rec["src_entity_key"],
                    src_entity_path = p_src_sys_rec["src_entity_path"],
                    src_entity_name = entity_s3_rec['Key'].split("/")[-1],
                    src_entity_timestamp = entity_s3_rec['LastModified'],
                    src_entity_size = entity_s3_rec['Size'],
                    src_entity_load_status = "staged",
                    src_entity_load_mesg = "Staged",
                    src_entity_load_run_id = uuid.uuid4(),
                    src_sys_id = p_src_sys_rec["src_sys_id"],
                    src_entity_id = p_src_entity_rec["src_entity_id"],                                                                    
                    src_entity_staged_time = datetime.now())                    
                for entity_s3_rec in page['Contents'] if fnmatch.fnmatch(entity_s3_rec['Key'],l_file_filter)]
            #
            if not l_entity_recs:
                  print(f"""Search in {p_src_sys_rec["src_entity_path"]}, for {l_entity_search_pattern} returned zero files""")
                  return l_entity_recs
            #
            if p_src_entity_rec["src_extract_type"] == "full":
                  l_sorted_recs = sorted(l_entity_recs, key=lambda frec: frec['src_entity_timestamp'], reverse=True)
                  #return l_sorted_recs
            elif p_src_entity_rec["src_extract_type"] == "incremental":
                  l_sorted_recs = sorted(l_entity_recs, key=lambda frec: frec['src_entity_timestamp'], reverse=False) 
                  #return l_sorted_recs      
            print("The following is list of file(s) found")
            print("%-26s %-50s" % ("Timestamp","File Name"))
            print("%-26s %-50s" % ("-"*26,"-"*50))
            for frec in l_sorted_recs:
                  print("%-26s %-50s" % (frec["src_entity_timestamp"].strftime("%Y-%m-%d %H:%M:%S.%f"),frec["src_entity_name"]))
            #
            return l_sorted_recs
    #        
#
def skip_files_other_than_first(p_files_list:list):
    for frec_indx in range(1,p_files_list.size-1):
        print(f"""{p_files_list[frec_indx]["src_entity_name"]} willl be marked skipped""")
#
def mark_file_processed(p_src_file_rec:Row,p_process_status:str):
    
    print(f"{p_src_file_rec['src_entity_name']} processed status = {p_process_status}")        

def stage_new_files():
    print("Printing new files")
def get_unprocessed_source_files(p_mapping_json:dict):

    l_src_sys_rec = Row(
         src_sys_key = p_mapping_json.get("SourceSystemID"),
         src_entity_path = "s3a://dataverse-dev/data/nabu/amp",
         src_sys_id = 1000,
    )
    l_src_entity_rec = Row(
          src_sys_key = p_mapping_json.get("SourceSystemID"),
          src_entity_last_inst_no = 1000,
          src_entity_key   = p_mapping_json.get("SourceFileID"),       
          src_entity_id = 1000,
          src_entity_pattern = p_mapping_json.get("SourceFilePattern"),
          src_extract_type = p_mapping_json.get("SourceExtractType")
    )
    return collect_all_files(l_src_sys_rec,l_src_entity_rec)