# Dataverse-sap-extract
Repository for Data Ingestion from sap into Dataverse
